#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/India.csv') 


# In[5]:


dataset


# In[6]:


df=pd.DataFrame(dataset)


# In[7]:


df


# In[14]:


tips=dataset.corr()
tips


# In[27]:


fig, ax = plt.subplots(figsize=(10,6))
sns.heatmap(dataset.corr(), center=0, cmap='Blues')


# In[26]:


sns.barplot(x='State/UnionTerritory' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depiction, shows, the, number, of, confirmed, cases, in, various, states, of, India., Maharashtra, has, the, highest, number, of, confirmed, cases, whereas, Mizoram, is, the, least.)


# In[2]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dataset=pd.read_csv('C:/Users/Dell/Desktop/Karnataka.csv') 


# In[3]:


dataset


# In[72]:


dataset.hist(alpha=0.5, figsize=(20, 10))
sns.distplot(dataset['Confirmed'],bins=75)


# In[13]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dataset=pd.read_csv('C:/Users/Dell/Desktop/India.csv') 


# In[14]:


dataset


# In[67]:


dataset.hist(alpha=0.5, figsize=(20, 10))
sns.distplot(dataset['Confirmed'],bins=75)


# In[16]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dataset=pd.read_csv('C:/Users/Dell/Desktop/Maharashtra.csv') 


# In[17]:


dataset


# In[69]:


dataset.hist(alpha=0.5, figsize=(20, 10))
sns.distplot(dataset['Confirmed'],bins=75)


# In[20]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/clean_data_covid.csv') 


# In[21]:


dataset


# In[22]:


fig, ax = plt.subplots(figsize=(10,6))
sns.heatmap(dataset.corr(), center=0, cmap='Blues')


# In[23]:


sns.barplot(x='State/UnionTerritory' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[28]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/AndhraPradesh.csv') 


# In[29]:


dataset


# In[48]:


sns.barplot(x='Date' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, confirmed, cases, in, Andhra, Pradesh, is, rising, everyday, by, a, small, margin.)


# In[49]:


sns.barplot(x='Date' ,y='Cured', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, cured, cases, in, Andhra, Pradesh, is, rising, everyday, by, a, small, margin.)


# In[51]:


sns.barplot(x='Date' ,y='Active cases', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, active, cases, in, Andhra, Pradesh, was, decreasing, in, initial, days, of, the, covid, month, but, now, there, is, again, a, sudden, uphill.)


# In[36]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/Gujarat.csv') 


# In[39]:


dataset


# In[74]:


sns.barplot(x='Date' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, confirmed, cases, in, Gujrat, is, constantly, rising, everyday.)


# In[52]:


sns.barplot(x='Date' ,y='Cured', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, cured, cases, in, Gujrat, is, rising, everyday, by, a, small, margin.)


# In[53]:


sns.barplot(x='Date' ,y='Active cases', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, Active, cases, in, Gujrat, is, having, us, with, a, variation, graph, of, ups, and, downs.)


# In[37]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/Maharashtra.csv') 


# In[40]:


dataset


# In[54]:


sns.barplot(x='Date' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, confirmed, cases, in, Maharashtra, is, rising, everyday, by, a, small, margin.)


# In[55]:


sns.barplot(x='Date' ,y='Cured', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, cured, cases, in, Maharashtra, is, rising, everyday, by, a, small, margin.)


# In[56]:


sns.barplot(x='Date' ,y='Active cases', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, active, cases, in, Maharashtra, is, rising, for, the, last, few, days, of, october.)


# In[38]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/Mizoram.csv') 


# In[41]:


dataset


# In[57]:


sns.barplot(x='Date' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, confirmed, cases, in, Mizoram, is, rising, everyday, by, a, small, margin.)


# In[58]:


sns.barplot(x='Date' ,y='Cured', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, cured, cases, in, Mizoram, is, rising, everyday, by, a, small, margin.)


# In[59]:


sns.barplot(x='Date' ,y='Active cases', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, active, cases, in, Mizoram, was, in, control, in, mid, month, of, october.)


# In[60]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

dataset=pd.read_csv('C:/Users/Dell/Desktop/Kerala.csv') 


# In[61]:


dataset


# In[62]:


sns.barplot(x='Date' ,y='Cured', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, cured, cases, in, Kerala, is, continuosly, increasing.)


# In[63]:


sns.barplot(x='Date' ,y='Confirmed', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, confirmed, cases, in, Kerala, is, rising, everyday, by, a, small, margin.)


# In[64]:


sns.barplot(x='Date' ,y='Active cases', data=dataset.tail(27))
plt.xticks(rotation=90)


# In[ ]:


(/the, above, graph, depicts, that, the, number, of, active, cases, in, Kerala, is, rising, and, falling, everyday.)


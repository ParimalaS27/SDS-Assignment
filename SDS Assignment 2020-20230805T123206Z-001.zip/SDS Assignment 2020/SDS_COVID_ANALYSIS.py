#!/usr/bin/env python
# coding: utf-8

# In[165]:


import pandas as pd
import numpy as np

df = pd.read_csv(r'C:\Users\91944\Documents\THIRD SEMESTER\DATA SCIENCE\Assignments\covid_19_india.csv')
df


# In[166]:


df.head()


# In[167]:


df.isnull().sum()


# In[168]:


df.isnull().sum().sum()


# In[169]:


df.shape


# In[170]:


df.info()


# In[171]:


df.describe()


# Filling missing values- Imputation 
# No dropping as values seem relevant

# In[172]:


median_foreign = df['Total_Confirmed_cases_Foreign_National'].median()
df['Total_Confirmed_cases_Foreign_National'].fillna(median_foreign,inplace = True)
df.tail()


# The operation below is of Multiporpose
# It fills the missing data .
# It also helps to replace incorrect and incosistent data in the column.

# In[173]:


df['Total_Confirmed_cases_Indian_National'] = df['Confirmed'] - df['Total_Confirmed_cases_Foreign_National'];
df


# In[174]:


df['State/UnionTerritory'].fillna("Unassigned",inplace = True)
df.tail()


# In[175]:


df.isnull().sum().sum()


# Dropping Serial Number column as it is not required.
# Time column may seem unwanted, but has got some small insights to be extracted. ;)

# In[176]:


del df['Serial']
df.head()


# Adding some new columns - computed from the existing columns to get more statiscally meaningful variables

# In[177]:


df['Active cases'] = (df['Confirmed'] - df['Deaths'] - df['Cured'])
df.head()


# In[178]:


df['%Death rate'] = (df['Deaths']/df['Confirmed'])*100
df['%Death rate'].fillna(0,inplace = True)
df.head()


# In[179]:


df['%Cure rate'] = (df['Cured']/df['Confirmed'])*100
df['%Cure rate'].fillna(0,inplace = True)
df.head()


# In[180]:


df['%Active rate'] = (df['Active cases']/df['Confirmed'])*100
df['%Active rate'].fillna(0,inplace = True)
df.head()


# Now these percentage values computed are for each day. In the sense, each cell value denotes the corresponding percentage for that particular day.

# Now we are going to create sub dataframes for the states.

# In[181]:


Karnataka_df = df.loc[df['State/UnionTerritory'] == "Karnataka"]
del Karnataka_df['State/UnionTerritory']
Karnataka_df.head()


# In[182]:


Kerala_df = df.loc[df['State/UnionTerritory'] == "Kerala"]
del Kerala_df['State/UnionTerritory']
Kerala_df.head()


# In[183]:


TamilNadu_df = df.loc[df['State/UnionTerritory'] == "Tamil Nadu"]
del TamilNadu_df['State/UnionTerritory']
TamilNadu_df.head()


# In[184]:


Delhi_df = df.loc[df['State/UnionTerritory'] == "Delhi"]
del Delhi_df['State/UnionTerritory']
Delhi_df.head()


# In[185]:


Maharashtra_df = df.loc[df['State/UnionTerritory'] == "Maharashtra"]
del Maharashtra_df['State/UnionTerritory']
Maharashtra_df.head()


# In[186]:


Mizoram_df = df.loc[df['State/UnionTerritory'] == "Mizoram"]
del Mizoram_df['State/UnionTerritory']
Mizoram_df.head()


# In[187]:


DadraNagarHaveliDamanDiu_df = df.loc[df['State/UnionTerritory'] == "Dadra and Nagar Haveli and Daman and Diu"]
del DadraNagarHaveliDamanDiu_df['State/UnionTerritory']
DadraNagarHaveliDamanDiu_df.head()


# In[188]:


Gujarat_df = df.loc[df['State/UnionTerritory'] == "Gujarat"]
del Gujarat_df['State/UnionTerritory']
Gujarat_df.head()


# In[189]:


AndhraPradesh_df = df.loc[df['State/UnionTerritory'] == "Andhra Pradesh"]
del AndhraPradesh_df['State/UnionTerritory']
AndhraPradesh_df.head()


# Creating a summational Dataframe for India

# In[198]:


# TODO
#Create a Dataframe for India
from datetime import datetime 
India_df = pd.DataFrame()
set_day = set()
deaths = list()
cured = list()
confirmed = list()
time = list()

for day in df['Date']:
    set_day.add(day)
    
Dates = list(set_day)

Dates.sort(key = lambda date: datetime.strptime(date, '%d-%m-%Y'))
India_df['Date'] = Dates

matrix = df.groupby('Date')['Cured'].sum()

diction_cured = dict()
date_sort = list(set_day)
date_sort.sort()

for i in range(0,len(Dates)):
    diction_cured[date_sort[i]] = matrix[i]
    
    
from collections import OrderedDict
ordered = OrderedDict(sorted(diction_cured.items(), key=lambda t: datetime.strptime(t[0] , '%d-%m-%Y')))

cured = list(ordered.values())

India_df['Cured'] = cured

#DEATHS
matrix = df.groupby('Date')['Deaths'].sum()
diction_death = dict()

for i in range(0,len(Dates)):
    diction_death[date_sort[i]] = matrix[i]
    
    
ordered = OrderedDict(sorted(diction_death.items(), key=lambda t: datetime.strptime(t[0] , '%d-%m-%Y')))

deaths = list(ordered.values())
print(len(deaths))

India_df['Death'] = deaths


India_df.tail()


# In[205]:


#CONFIRMED
confirm = list()
matrix = df.groupby('Date')['Confirmed'].sum()
diction_confirm = dict()
date_sort = list(set_day)
date_sort.sort()

for i in range(0,len(Dates)):
    diction_confirm[date_sort[i]] = matrix[i]
    
ordered = OrderedDict(sorted(diction_confirm.items(), key=lambda t: datetime.strptime(t[0] , '%d-%m-%Y')))
confirm= ordered.values()
India_df['Confirmed'] = confirm

India_df.tail()


# In[206]:


#CONFIRMED
confirm = list()
matrix = df.groupby('Date')['Total_Confirmed_cases_Indian_National'].sum()
diction_confirm = dict()
date_sort = list(set_day)
date_sort.sort()

for i in range(0,len(Dates)):
    diction_confirm[date_sort[i]] = matrix[i]
    
ordered = OrderedDict(sorted(diction_confirm.items(), key=lambda t: datetime.strptime(t[0] , '%d-%m-%Y')))
confirm= ordered.values()
India_df['Total_Confirmed_cases_Indian_National'] = confirm

India_df.tail()


# In[207]:


#CONFIRMED
confirm = list()
matrix = df.groupby('Date')['Total_Confirmed_cases_Foreign_National'].sum()
diction_confirm = dict()
date_sort = list(set_day)
date_sort.sort()

for i in range(0,len(Dates)):
    diction_confirm[date_sort[i]] = matrix[i]
    
ordered = OrderedDict(sorted(diction_confirm.items(), key=lambda t: datetime.strptime(t[0] , '%d-%m-%Y')))
confirm= ordered.values()
India_df['Total_Confirmed_cases_Foreign_National'] = confirm

India_df.tail()


# In[209]:


India_df['Active cases'] = (India_df['Confirmed'] - India_df['Death'] - India_df['Cured'])
India_df['%Death rate'] = (India_df['Death']/India_df['Confirmed'])*100
India_df['%Death rate'].fillna(0,inplace = True)

India_df['%Cure rate'] = (India_df['Cured']/India_df['Confirmed'])*100
India_df['%Cure rate'].fillna(0,inplace = True)

India_df['%Active rate'] = (India_df['Active cases']/India_df['Confirmed'])*100
India_df['%Active rate'].fillna(0,inplace = True)

India_df.head()


# In[210]:


import csv
df.to_csv(r'C:\Users\91944\Downloads\clean_data_covid.csv', encoding='utf-8',index=False)


# In[211]:


Karnataka_df.to_csv(r'C:\Users\91944\Downloads\Karnataka.csv', encoding='utf-8',index=False)
Kerala_df.to_csv(r'C:\Users\91944\Downloads\Kerala.csv', encoding='utf-8',index=False)
TamilNadu_df.to_csv(r'C:\Users\91944\Downloads\TamilNadu.csv', encoding='utf-8',index=False)
Gujarat_df.to_csv(r'C:\Users\91944\Downloads\Gujarat.csv', encoding='utf-8',index=False)
AndhraPradesh_df.to_csv(r'C:\Users\91944\Downloads\AndhraPradesh.csv', encoding='utf-8',index=False)
Maharashtra_df.to_csv(r'C:\Users\91944\Downloads\Maharashtra.csv', encoding='utf-8',index=False)
Mizoram_df.to_csv(r'C:\Users\91944\Downloads\Mizoram.csv', encoding='utf-8',index=False)
Delhi_df.to_csv(r'C:\Users\91944\Downloads\Delhi.csv', encoding='utf-8',index=False)
DadraNagarHaveliDamanDiu_df.to_csv(r'C:\Users\91944\Downloads\DadraNagarHaveliDamanDiu.csv', encoding='utf-8',index=False)


# In[212]:


India_df.to_csv(r'C:\Users\91944\Downloads\Karnataka.csv', encoding='utf-8',index=False)


# In[ ]:





#!/usr/bin/env python
# coding: utf-8

# In[5]:


import scipy.stats as stats


# In[15]:


import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dataset=pd.read_csv('C:/Users/Dell/Desktop/covid_19_india.csv') 


# In[16]:


dataset


# In[51]:



covid = dataset[['%Activerate', 'State/UnionTerritory']]
covid.head()


# In[44]:


covid['Total_Confirmed_cases_Indian_National'].value_counts()


# In[45]:


covid['State/UnionTerritory'].value_counts()


# In[46]:


contingency_table = pd.crosstab(
    covid['Total_Confirmed_cases_Indian_National'],
    covid['State/UnionTerritory'],
    margins = True
)
contingency_table


# In[47]:


f_obs = np.append(contingency_table.iloc[0][0:6].values, contingency_table.iloc[1][0:6].values)
f_obs


# In[48]:


row_sums = contingency_table.iloc[0:2,6].values
row_sums


# In[38]:


col_sums = contingency_table.iloc[2,0:6].values
col_sums


# In[39]:


total = contingency_table.loc['All', 'All']

f_expected = []
for j in range(2):
    for i in col_sums:
        f_expected.append(i*row_sums[j]/total)
f_expected


# In[40]:


chi_squared_statistic = ((f_obs - f_expected)**2/f_expected).sum()
print('Chi-squared Statistic: {}'.format(chi_squared_statistic))


# In[41]:


dof = (len(row_sums)-1)*(len(col_sums)-1)
print("Degrees of Freedom: {}".format(dof))


# In[42]:


f_obs = np.array([contingency_table.iloc[0][0:6].values,
                  contingency_table.iloc[1][0:6].values])
f_obs


# In[31]:


from scipy import stats
stats.chi2_contingency(f_obs)[0:3]


# In[ ]:




